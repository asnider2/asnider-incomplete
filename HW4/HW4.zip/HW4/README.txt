Did you discuss this assignment with any other students? Please list their cs logins.
no
How many late days are you using on this assignment?
too many